# Portfolio Backend

Backend de mi portfolio personal, desarrollado en Springboot, seguridad implementada a través de JWT, y uso del repositorio JPA.

